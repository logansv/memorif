Use tcc;
INSERT INTO Administrador(id, nome, cpf, email, senha)
VALUES (null, 'ana', '243' 'ana@gmail.com', '1234');
