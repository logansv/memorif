package br.edu.ifpr.bean;

import java.util.ArrayList;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name="arquivo")
public class Arquivo {
    private int id;
    private String titulo;
    private String palavraChave;
    private String descricao;
    private String dataArquivo;
    private String categoria;
    private String arquivo;
    private String tipo;

    public Arquivo(){}

    public Arquivo(int id, String titulo, String palavraChave, String descricao, String dataArquivo, String categoria, String arquivo, String tipo) {
        this.id = id;
        this.titulo = titulo;
        this.palavraChave = palavraChave;
        this.descricao = descricao;
        this.dataArquivo = dataArquivo;
        this.categoria = categoria;
        this.arquivo = arquivo;
        this.tipo = tipo;
    }


    
    @Id
    @GeneratedValue (strategy = GenerationType.AUTO)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(length = 200, name = "titulo", nullable = false) 
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    
    @Column(length = 200, name = "palavrachave", nullable = false) 
    public String getPalavraChave() {
        return palavraChave;
    }

    public void setPalavraChave(String palavraChave) {
        this.palavraChave = palavraChave;
    }
    
    @Column(length = 200, name = "descricao", nullable = false) 
    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
    @Column(length = 200, name = "data", nullable = false) 
    public String getDataArquivo() {
        return dataArquivo;
    }

    public void setDataArquivo(String dataArquivo) {
        this.dataArquivo = dataArquivo;
    }
    
    @Column(length = 200, name = "arquivo", nullable = false) 
    public String getArquivo() {
        return arquivo;
    }

    public void setArquivo(String arquivo) {
        this.arquivo = arquivo;
    }

    @Column(length = 200, name = "tipo", nullable = false) 
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

     @Column(length = 200, name = "categoria", nullable = false) 
    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }


    
    
    
}
