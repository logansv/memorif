/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifpr.model.dao;

import br.edu.ifpr.bean.Administrador;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;


/**
 *
 * @author guest-i43g6h
 */
public class AdministradorDao extends GenericDAO<Integer, Administrador> {
    
    public AdministradorDao(){}
    
    public Administrador getByNome(String nome){
        TypedQuery<Administrador> query = em.createQuery("SELECT a FROM Administrador a WHERE a.nome = :nome", Administrador.class);
        
        return query.setParameter("nome", nome).getSingleResult();
    }
    
    public Administrador logar(String email, String senha){
        TypedQuery<Administrador> query = em.createQuery("SELECT a FROM Administrador a WHERE a.email = :email AND a.senha = :senha", Administrador.class);
        
        query.setParameter("email", email);
        query.setParameter("senha", senha);
        
        Administrador administrador = null;
        
        try {
            administrador = query.getSingleResult();
        } catch (NoResultException e) {
            administrador = null;
        }
        
        return administrador;
    }   
    
    public List<Administrador> getMenosLogado(int id){
        TypedQuery<Administrador> query = em.createQuery("SELECT a FROM Administrador a WHERE a.id <> :id", Administrador.class);
        
        return query.setParameter("id", id).getResultList();
    }
}
/* 
public class UsuarioDAO extends GenericDAO<Integer, Usuario>{

    public UsuarioDAO() {
    }
    
    public Usuario getByNome(String nome){
        TypedQuery<Usuario> query = em.createQuery("SELECT u FROM Usuario u WHERE u.nome = :nome", Usuario.class);
        
        return query.setParameter("nome", nome).getSingleResult();
    }
    
    public Usuario logar(String email, String senha){
        TypedQuery<Usuario> query = em.createQuery("SELECT u FROM Usuario u WHERE u.email = :email AND u.senha = :senha", Usuario.class);
        
        query.setParameter("email", email);
        query.setParameter("senha", senha);
        
        Usuario usuario = null;
        
        try {
            usuario = query.getSingleResult();
        } catch (NoResultException e) {
            usuario = null;
        }
        
        return usuario;
    }
    
    public List<Usuario> getMenosLogado(int id){
        TypedQuery<Usuario> query = em.createQuery("SELECT u FROM Usuario u WHERE u.id <> :id", Usuario.class);
        
        return query.setParameter("id", id).getResultList();
    }

}

*/