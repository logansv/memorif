/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifpr.model;

import br.edu.ifpr.bean.ArquivoRecebido;
import br.edu.ifpr.model.dao.ArquivoRecebidoDao;
import java.util.ArrayList;

/**
 *
 * @author guest-we6m4z
 */
public class ArquivoRecebidoModel {
     ArquivoRecebidoDao dao = new ArquivoRecebidoDao();
    
    public ArquivoRecebido getArquivoById(int id){
        return dao.getById(id);
    }
    
    public ArrayList<ArquivoRecebido> getArquivoRecebido() {
        ArquivoRecebidoDao mdao = new ArquivoRecebidoDao();
        return (ArrayList<ArquivoRecebido>) mdao.findAll();
    }
    
    public ArquivoRecebido getArquivoRecebido(int id) {
        ArquivoRecebidoDao mdao = new ArquivoRecebidoDao();
        return mdao.get(id);
        
    }
        
    public void add(ArquivoRecebido a){
        ArquivoRecebidoDao mdao = new ArquivoRecebidoDao();
        mdao.create(a);
    }
    
    public void update(ArquivoRecebido m){
        
    }
    
    public void remove(int id){
        ArquivoRecebidoDao mdao = new ArquivoRecebidoDao();
        mdao.remove(id);
    }
    
    public ArrayList<ArquivoRecebido>  getArquivos(){
         return (ArrayList<ArquivoRecebido>) dao.findAll();
    }
   
}
