/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifpr.model;

import br.edu.ifpr.bean.Administrador;
import br.edu.ifpr.model.dao.AdministradorDao;


import java.util.ArrayList;

/**
 *
 * @author luis
 */
public class AdministradorModel {
    AdministradorDao dao = new AdministradorDao();
    
        
    public Administrador getUsuario(int id){
        return dao.get(id);
    }
        
    public void add(Administrador u){
        dao.create(u);
    }
    
   /* public void update(Administrador u){
        Administrador cadastrado = getUsuarioByNome(u.getNome());
        
        if (cadastrado == null || (cadastrado.getId() == u.getId())) {
            dao.update(u);
        }
    } */
    
    public Administrador getUsuarioByNome(String nome){
        return dao.getByNome(nome);
    }
    
    public void remove(int id){
        dao.remove(id);
    }
    
    public Administrador logar(String email, String senha){
        return dao.logar(email, senha);
    }
    
    public ArrayList<Administrador> getMenosLogado(int idAdministrador){
        return (ArrayList<Administrador>)dao.getMenosLogado(idAdministrador);
    }

}
