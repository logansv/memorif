/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifpr.model;

import br.edu.ifpr.bean.Arquivo;
import br.edu.ifpr.model.dao.ArquivoDao;
import br.edu.ifpr.model.dao.ArquivoRecebidoDao;
import br.edu.ifpr.model.dao.GenericDAO;
import java.util.ArrayList;

/**
 *
 * @author guest-jcvko4
 */
public class ArquivoModel {
    ArquivoDao dao = new ArquivoDao();
    
    public Arquivo getArquivoById(int id){
        return dao.getById(id);
    }
    
    public ArrayList<Arquivo> getArquivo() {
        ArquivoDao mdao = new ArquivoDao();
        return (ArrayList<Arquivo>) mdao.findAll();
    }
    
    public Arquivo getArquivo(int id) {
        ArquivoDao mdao = new ArquivoDao();
        return mdao.get(id);
        
    }
        
    public void add(Arquivo a){
        ArquivoDao mdao = new ArquivoDao();
        mdao.create(a);
    }
    
    public void update(Arquivo m){
        
    }
    
    public void remove(int id){
        ArquivoDao mdao = new ArquivoDao();
        mdao.remove(id);
    }
    
    public ArrayList<Arquivo>  getArquivos(){
         return (ArrayList<Arquivo>) dao.findAll();
    }
    
    
    public ArrayList<Arquivo>  getArquivoByCategoria(String categoria){
        ArquivoDao mdao = new ArquivoDao();
        return (ArrayList<Arquivo>) dao.getByCategoria(categoria);
    }
}
