/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifpr.model.dao;

import br.edu.ifpr.bean.ArquivoRecebido;
import java.util.List;
import javax.persistence.TypedQuery;

/**
 *
 * @author guest-we6m4z
 */
public class ArquivoRecebidoDao extends GenericDAO<Integer, ArquivoRecebido>{
     
    public ArquivoRecebidoDao() {
        super();
    }
     
    public ArquivoRecebido getById(int id){
        TypedQuery<ArquivoRecebido> query = em.createQuery("SELECT a FROM ArquivoRecebido a WHERE a.id = :id", ArquivoRecebido.class);
        
        return query.setParameter("id", id).getSingleResult();
    }
      
}
