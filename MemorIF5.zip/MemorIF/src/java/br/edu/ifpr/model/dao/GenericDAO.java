/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifpr.model.dao;

import java.lang.reflect.ParameterizedType;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author luis
 */
public class GenericDAO<Pk, Entity> {
    private static final EntityManagerFactory factory = 
           Persistence.createEntityManagerFactory("tcc");
    
    EntityManager em;
    
    public GenericDAO(){
        this.em = factory.createEntityManager();
    }
    
    public void create(Entity e){
        em.getTransaction().begin();
        em.persist(e);
        em.getTransaction().commit();
        em.close();
    }
    
    public Entity get(Pk pk) {
        Entity entity = (Entity) em.find(getTypeClass(), pk);
        em.close();
        
        return entity;
    }
    
    public void update(Entity e){
        em.getTransaction().begin();
        em.merge(e);
        em.getTransaction().commit();
        em.close();
        
    }
    
    public List<Entity> findAll(){
        return em.createQuery("FROM " + getTypeClass().getName()).getResultList();
    }
    
    public void remove(Pk pk){
        Entity cadastrada = (Entity) em.find(getTypeClass(), pk);
        em.getTransaction().begin();
        em.remove(cadastrada);
        em.getTransaction().commit();
        em.close();

    }
    
    private Class<?> getTypeClass() {
        Class<?> clazz = (Class<?>) ((ParameterizedType) this.getClass().getGenericSuperclass()).getActualTypeArguments()[1];
        return clazz;
    }
    
}



/*

package br.edu.ifpr.model.dao;

import java.lang.reflect.ParameterizedType;
import java.util.List;
import javax.persistence.EntityManager;

public class GenericDAO<PK, T> {
    
    protected EntityManager em;

    public GenericDAO(EntityManager em) {
        this.em = em;
    }
    
    public void create(T entity) {
        em.getTransaction().begin();
        em.persist(entity);
        em.getTransaction().commit();
    }
    
    public T retrieve(PK pk) {
        T entity = (T) em.find(getTypeClass(), pk);
        return entity;
    }
    
    public void update(T entity) {
        em.getTransaction().begin();
        em.merge(entity);
        em.getTransaction().commit();
    }
    
    public void delete(PK pk) {
        em.getTransaction().begin();
        T entity = (T) em.find(getTypeClass(), pk);
        em.remove(entity);
        em.getTransaction().commit();
    }
    
    public List<T> findAll() {
        List<T> entities;
        entities = em.createQuery("FROM " + getTypeClass().getName()).getResultList();
        return entities;
    }
    
 
    private Class<?> getTypeClass() {
        Class<?> clazz = (Class<?>) ((ParameterizedType) this.getClass().getGenericSuperclass()).getActualTypeArguments()[1];
        return clazz;
    }
}
*/
