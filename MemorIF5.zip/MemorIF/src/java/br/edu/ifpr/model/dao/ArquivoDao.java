/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifpr.model.dao;

import br.edu.ifpr.bean.Arquivo;
import java.util.List;
import javax.persistence.TypedQuery;

/**
 *
 * @author guest-jcvko4
 */
public class ArquivoDao extends GenericDAO<Integer, Arquivo>{
    public ArquivoDao() {
        super();
    }
     
    public Arquivo getById(int id){
        TypedQuery<Arquivo> query = em.createQuery("SELECT a FROM Arquivo a WHERE a.id = :id", Arquivo.class);
        
        return query.setParameter("id", id).getSingleResult();
    }
    
    public List<Arquivo> getByCategoria(String categoria){
        TypedQuery<Arquivo> query = em.createQuery("SELECT a FROM Arquivo a WHERE a.categoria = :categoria", Arquivo.class);
        
        return query.setParameter("categoria", categoria).getResultList();
    }
}
