package br.edu.ifpr.controller;

import br.edu.ifpr.bean.Administrador;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "ADMProjeto", urlPatterns = {"/ADMProjeto"})
public class ADMProjeto extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession sessao = request.getSession(false);
        Administrador logado = (Administrador)sessao.getAttribute("logado");
        
        if (logado == null){
            response.sendRedirect("PaginaInicial");
        } else{
            request.getRequestDispatcher("WEB-INF/jsp/ADMProjetos.jsp").forward(request, response);
        }
       
    }


}
