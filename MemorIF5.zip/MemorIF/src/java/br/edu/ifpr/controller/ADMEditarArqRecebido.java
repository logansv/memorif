package br.edu.ifpr.controller;

import br.edu.ifpr.bean.Administrador;
import br.edu.ifpr.bean.Arquivo;
import br.edu.ifpr.model.ArquivoModel;
import br.edu.ifpr.model.ArquivoRecebidoModel;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

@WebServlet(name = "ADMEditarArqRecebido", urlPatterns = {"/ADMEditarArqRecebido"})
@MultipartConfig(fileSizeThreshold = 1024 * 1024,
        maxFileSize = 1024 * 1024 * 5,
        maxRequestSize = 1024 * 1024 * 5 * 5,
        location = "/tmp/guest-kujcp7/Área de Trabalho/arquivos/")

public class ADMEditarArqRecebido extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession sessao = request.getSession(false);
        Administrador logado = (Administrador) sessao.getAttribute("logado");

        if (logado == null) {
            response.sendRedirect("PaginaInicial");
        } else {
            int index = Integer.parseInt(request.getParameter("index"));
            
            ArquivoRecebidoModel arq = new ArquivoRecebidoModel();
            arq.getArquivoById(index);
            
            
            request.setAttribute("arquivo", arq.getArquivoById(index));
       
       
            request.getRequestDispatcher("WEB-INF/jsp/ADMEditarArqRecebido.jsp").forward(request, response);
            
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        
        String titulo = request.getParameter("titulo");
        String palavrachave = request.getParameter("palavrachave");
        String descricao = request.getParameter("descricao");
        String dataArquivo = request.getParameter("dataArquivo");
        String categoria = request.getParameter("categoria");
        
        String arquivo = request.getParameter("arquivo");
        String tipo = request.getParameter("tipo");
        
        //request.getParameter("arquivo");
        //request.getParameter("tipo");
        
        //Part filePart;

        // obtendo o arquivo, semelhante ao getParameter
        //filePart = request.getPart("arquivo");
  
        
        //filePart.write(filePart.getSubmittedFileName());
        //arquivo
        
        //request.setAttribute("arquivo", filePart.getSubmittedFileName());
        //request.setAttribute("tipo", filePart.getContentType());
        
        Arquivo arquivo1 = new Arquivo(0, titulo, palavrachave, descricao, dataArquivo, categoria, arquivo, tipo);
        new ArquivoModel().add(arquivo1);
        
        int index = Integer.parseInt(request.getParameter("index"));
        new ArquivoRecebidoModel().remove(index);
        
        response.sendRedirect("ADMColecoes");
    }
}
