package br.edu.ifpr.controller;

import br.edu.ifpr.bean.Administrador;
import br.edu.ifpr.bean.ArquivoRecebido;
import br.edu.ifpr.model.ArquivoRecebidoModel;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "ADMRemoverArqRecebido", urlPatterns = {"/ADMRemoverArqRecebido"})
public class ADMRemoverArqRecebido extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession sessao = request.getSession(false);
        Administrador logado = (Administrador)sessao.getAttribute("logado");
        
        if (logado == null){
            response.sendRedirect("PaginaInicial");
        } else{
             int index = Integer.parseInt(request.getParameter("index"));
             new ArquivoRecebidoModel().remove(index);
            response.sendRedirect("ADMArquivoRecebido");
        }
        
        
    }
}
