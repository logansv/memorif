/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifpr.controller;
import br.edu.ifpr.bean.ArquivoRecebido;
import br.edu.ifpr.model.ArquivoRecebidoModel;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 *
 * @author guest-1uxk8e
 */
@WebServlet(name = "EnviarArquivo", urlPatterns = {"/EnviarArquivo"})
@MultipartConfig(fileSizeThreshold = 1024 * 1024,
        maxFileSize = 1024 * 1024 * 5,
        maxRequestSize = 1024 * 1024 * 5 * 5,
        location = "/tmp/guest-kujcp7/Área de Trabalho/arquivos/")
public class EnviarArquivo extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("WEB-INF/jsp/EnviarArquivo.jsp").forward(request, response);
    }

 
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        
        String nome = request.getParameter("nome");
        String cpf = request.getParameter("cpf");
        String email = request.getParameter("email");
        String relacao = request.getParameter("relacao");
        String dataArquivo = request.getParameter("dataArquivo");
        String descricao = request.getParameter("descricao");
        
        Part filePart;

        // obtendo o arquivo, semelhante ao getParameter
        filePart = request.getPart("arquivo");
  
        
        filePart.write(filePart.getSubmittedFileName());
        //arquivo
        
        request.setAttribute("arquivo", filePart.getSubmittedFileName());
        request.setAttribute("tipo", filePart.getContentType());
        
        ArquivoRecebido arquivoRecebido1 = new ArquivoRecebido(0, nome, cpf, email ,relacao, dataArquivo, descricao, filePart.getSubmittedFileName(), filePart.getContentType());
        new ArquivoRecebidoModel().add(arquivoRecebido1);

        request.setAttribute("enviado", "Arquivo enviado com sucesso!");
        response.sendRedirect("PaginaInicial");
        
    }
    
     private static String getFileExtension(String fileName) {

        if (fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0) {
            return fileName.substring(fileName.lastIndexOf(".") + 1);
        } else {
            return "";
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
