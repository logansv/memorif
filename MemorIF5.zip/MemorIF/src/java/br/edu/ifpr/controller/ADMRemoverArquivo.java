/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifpr.controller;

import br.edu.ifpr.bean.Administrador;
import br.edu.ifpr.model.ArquivoModel;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author guest-49w8a3
 */
@WebServlet(name = "ADMRemoverArquivo", urlPatterns = {"/ADMRemoverArquivo"})
public class ADMRemoverArquivo extends HttpServlet {

    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession sessao = request.getSession(false);
        Administrador logado = (Administrador)sessao.getAttribute("logado");
        
        if (logado == null){
            response.sendRedirect("PaginaInicial");
        } else{
             int index = Integer.parseInt(request.getParameter("index"));
             new ArquivoModel().remove(index);
            response.sendRedirect("ADMColecoes");
        }
    }

  

}
