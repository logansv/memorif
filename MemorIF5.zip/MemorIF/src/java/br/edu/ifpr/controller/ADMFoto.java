package br.edu.ifpr.controller;

import br.edu.ifpr.bean.Administrador;
import br.edu.ifpr.bean.Arquivo;
import br.edu.ifpr.model.ArquivoModel;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "ADMFoto", urlPatterns = {"/ADMFoto"})
public class ADMFoto extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession sessao = request.getSession(false);
        Administrador logado = (Administrador)sessao.getAttribute("logado");
        
        if (logado == null){
            response.sendRedirect("PaginaInicial");
        } else{
            ArquivoModel arq = new ArquivoModel();
            ArrayList<Arquivo> arquivo = arq.getArquivoByCategoria("Fotos");
            request.setAttribute("arquivos", arquivo);


            request.getRequestDispatcher("WEB-INF/jsp/ADMFotos.jsp").forward(request, response);
        }
    }
}
